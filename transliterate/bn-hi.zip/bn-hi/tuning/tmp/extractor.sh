#!/bin/bash
cd /home/raj/ratish/project/icon-smt/moses/working-ems-bn-hi-translit/model/Transliteration.1/tuning/tmp
/home/raj/ratish/ililmt/statisticalpostediting/moses/mosesdecoder/mert/extractor  --scconfig case:true  --scfile run4.scores.dat --ffile run4.features.dat -r /home/raj/ratish/project/icon-smt/moses/working-ems-bn-hi-translit/model/Transliteration.1/tuning/reference -n run4.best100.out.gz
